<?php
include 'header.php';
?>
<div class="page-error-404">
    <div class="error-symbol"> <i class="entypo-gauge"></i> </div>
    <div class="error-text">
        <h2>Welcome</h2>
        <p>To Developer Panel</p>
    </div>
</div>
<?php
include 'footer.php';
?>