    <ul id="main-menu">
        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
        <!-- DASHBOARD -->
        <li class="active "><a href="../index/dashboard.php"><i class="entypo-gauge"></i><span>Dashboard</span></a></li>
        <li><a href="../activation/"><i class="entypo-lifebuoy"></i><span>Active Application</span></a></li>
		<li><a href="../user/User/Authentication/logout.php"><i class="entypo-logout right"></i><span>Log Out</span></a></li>
    </ul>